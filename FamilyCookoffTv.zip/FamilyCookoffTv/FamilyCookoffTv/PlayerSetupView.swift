//
//  PlayerSetupView.swift
//  FamilyCookoffTv
//
//  Player setup screen for Family Cook-Off.
//  Allows adding 2-4 players before starting the quiz game.
//

import SwiftUI

struct PlayerSetupView: View {
    @EnvironmentObject var game: GameViewModel
    
    // State for new player form
    @State private var newPlayerName: String = ""
    @State private var selectedAvatar: String = "fork.knife"
    @State private var selectedIngredient: String = "Tomato"
    @State private var showNameError: Bool = false
    @FocusState private var isNameFieldFocused: Bool
    
    // Available options
    let avatarOptions = ["fork.knife", "flame.fill", "leaf.fill", "takeoutbag.and.cup.and.straw.fill"]
    let ingredientOptions = ["Tomato", "Cheese", "Egg", "Chicken", "Garlic", "Onion", "Butter", "Basil"]
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.blue.opacity(0.2),
                    Color.purple.opacity(0.2)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 30) {
                    // Title
                    Text("Add Players")
                        .font(.system(size: 60, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                        .padding(.top, 30)
                    
                    // Existing players section
                    if !game.players.isEmpty {
                        existingPlayersSection
                    }
                    
                    // Add new player section
                    newPlayerSection
                    
                    // Start Quiz button
                    startQuizButton
                        .padding(.bottom, 40)
                }
                .padding(.horizontal, 60)
            }
        }
    }
    
    // MARK: - Existing Players Section
    
    private var existingPlayersSection: some View {
        VStack(spacing: 20) {
            HStack {
                Image(systemName: "person.3.fill")
                    .font(.system(size: 30))
                Text("Players (\(game.players.count)/4)")
                    .font(.system(size: 35, weight: .semibold))
                Spacer()
            }
            .foregroundColor(.secondary)
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 20) {
                ForEach(game.players) { player in
                    PlayerCard(player: player)
                        .environmentObject(game)
                }
            }
        }
    }
    
    // MARK: - New Player Section
    
    private var newPlayerSection: some View {
        VStack(spacing: 20) {
            HStack {
                Image(systemName: "person.badge.plus")
                    .font(.system(size: 28))
                Text("New Player")
                    .font(.system(size: 32, weight: .semibold))
                Spacer()
            }
            .foregroundColor(.primary)
            
            VStack(alignment: .leading, spacing: 20) {
                // Name TextField
                VStack(alignment: .leading, spacing: 10) {
                    Text("Name")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundColor(.secondary)
                    
                    TextField("Enter player name", text: $newPlayerName)
                        .textFieldStyle(.plain)
                        .font(.system(size: 30))
                        .padding()
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(8)
                        .frame(height: 70)
                        .focused($isNameFieldFocused)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(showNameError ? Color.red : Color.clear, lineWidth: 3)
                        )
                    
                    if showNameError {
                        Text("Please enter a player name")
                            .font(.system(size: 24))
                            .foregroundColor(.red)
                    }
                }
                
                // Avatar Picker
                VStack(alignment: .leading, spacing: 15) {
                    Text("Avatar")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 20) {
                        ForEach(avatarOptions, id: \.self) { avatar in
                            Button {
                                selectedAvatar = avatar
                            } label: {
                                Image(systemName: avatar)
                                    .font(.system(size: 45))
                                    .foregroundColor(selectedAvatar == avatar ? .white : .primary)
                                    .frame(width: 100, height: 100)
                                    .background(
                                        selectedAvatar == avatar ?
                                        LinearGradient(
                                            colors: [.orange, .pink],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ) : LinearGradient(
                                            colors: [Color.secondary.opacity(0.2)],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                                    .cornerRadius(15)
                            }
                            .buttonStyle(.card)
                        }
                    }
                }
                
                // Favourite Ingredient Picker
                VStack(alignment: .leading, spacing: 15) {
                    Text("Favourite Ingredient")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundColor(.secondary)
                    
                    Picker("Favourite Ingredient", selection: $selectedIngredient) {
                        ForEach(ingredientOptions, id: \.self) { ingredient in
                            Text(ingredient)
                                .font(.system(size: 28))
                                .tag(ingredient)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(height: 70)
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(10)
                }
                
                // Add Player Button
                Button {
                    addPlayer()
                } label: {
                    HStack(spacing: 15) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 32))
                        Text("Add Player")
                            .font(.system(size: 34, weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 75)
                    .background(
                        game.players.count < 4 ?
                        LinearGradient(
                            colors: [.green, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        ) : LinearGradient(
                            colors: [Color.secondary.opacity(0.3)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(15)
                }
                .buttonStyle(.card)
                .disabled(game.players.count >= 4)
            }
            .padding(30)
            .background(Color.secondary.opacity(0.1))
            .cornerRadius(20)
        }
    }
    
    // MARK: - Start Quiz Button
    
    private var startQuizButton: some View {
        VStack(spacing: 15) {
            if !game.canStartGame() {
                Text("Add at least 2 players to start")
                    .font(.system(size: 26))
                    .foregroundColor(.secondary)
            }
            
            NavigationLink {
                GameRoundView()
            } label: {
                HStack(spacing: 15) {
                    Image(systemName: "play.circle.fill")
                        .font(.system(size: 40))
                    Text("Start Quiz")
                        .font(.system(size: 42, weight: .bold))
                }
                .frame(width: 500, height: 100)
                .background(
                    game.canStartGame() ?
                    LinearGradient(
                        colors: [.orange, .pink],
                        startPoint: .leading,
                        endPoint: .trailing
                    ) : LinearGradient(
                        colors: [Color.secondary.opacity(0.3)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(20)
            }
            .buttonStyle(.card)
            .disabled(!game.canStartGame())
        }
    }
    
    // MARK: - Helper Methods
    
    private func addPlayer() {
        print("🎮 Add Player button tapped")
        
        // Validate name
        let trimmedName = newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines)
        print("📝 Trimmed name: '\(trimmedName)'")
        
        guard !trimmedName.isEmpty else {
            print("❌ Name is empty, showing error")
            showNameError = true
            return
        }
        
        guard game.players.count < 4 else {
            print("❌ Already have 4 players")
            return
        }
        
        print("✅ Adding player: \(trimmedName), avatar: \(selectedAvatar), ingredient: \(selectedIngredient)")
        
        // Add player via GameViewModel
        game.addPlayer(
            name: trimmedName,
            avatarSymbolName: selectedAvatar,
            favouriteIngredient: selectedIngredient
        )
        
        print("✅ Player added! Total players: \(game.players.count)")
        
        // Reset form
        newPlayerName = ""
        selectedAvatar = "fork.knife"
        selectedIngredient = "Tomato"
        showNameError = false
        
        // Optionally focus back on name field
        isNameFieldFocused = false
    }
}

// MARK: - Player Card Component

struct PlayerCard: View {
    let player: Player
    @EnvironmentObject var game: GameViewModel
    @State private var showDeleteConfirmation = false
    
    var body: some View {
        VStack(spacing: 15) {
            // Avatar
            Image(systemName: player.avatarSymbolName)
                .font(.system(size: 60))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.orange, .pink],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            // Name
            Text(player.name)
                .font(.system(size: 32, weight: .bold))
                .foregroundColor(.primary)
            
            // Favourite Ingredient
            HStack(spacing: 8) {
                Image(systemName: "heart.fill")
                    .font(.system(size: 20))
                Text(player.favouriteIngredient)
                    .font(.system(size: 24))
            }
            .foregroundColor(.secondary)
            
            // Remove button
            Button(action: {
                showDeleteConfirmation = true
            }) {
                HStack(spacing: 8) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 22))
                    Text("Remove")
                        .font(.system(size: 24))
                }
                .foregroundColor(.red)
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color.red.opacity(0.1))
                .cornerRadius(8)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity)
        .padding(30)
        .background(Color.secondary.opacity(0.1))
        .cornerRadius(15)
        .alert("Remove Player", isPresented: $showDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Remove", role: .destructive) {
                game.removePlayer(player)
            }
        } message: {
            Text("Remove \(player.name) from the game?")
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        PlayerSetupView()
            .environmentObject({
                let vm = GameViewModel()
                // Add sample players for preview
                vm.addPlayer(name: "Alice", avatarSymbolName: "fork.knife", favouriteIngredient: "Tomato")
                vm.addPlayer(name: "Bob", avatarSymbolName: "flame.fill", favouriteIngredient: "Cheese")
                return vm
            }())
    }
}
