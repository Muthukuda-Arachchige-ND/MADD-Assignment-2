//
//  GameModels.swift
//  FamilyCookoffTv
//
//  Core data models for the Family Cook-Off multiplayer cooking quiz game.
//  Contains Player, Question, Difficulty, and QuestionBank structures.
//

import Foundation

/// Represents a player in the game with their profile and score
/// Identifiable: allows SwiftUI to track players in lists
/// Hashable: enables comparison and storage in sets/dictionaries
struct Player: Identifiable, Hashable {
    let id: UUID
    var name: String
    var avatarSymbolName: String    // SF Symbol name for visual representation
    var favouriteIngredient: String
    var score: Int
    
    /// Initialize a new player with default score of 0
    init(id: UUID = UUID(), name: String, avatarSymbolName: String, favouriteIngredient: String, score: Int = 0) {
        self.id = id
        self.name = name
        self.avatarSymbolName = avatarSymbolName
        self.favouriteIngredient = favouriteIngredient
        self.score = score
    }
}

/// Difficulty levels for quiz questions
/// CaseIterable: enables iterating through all cases
/// Codable: allows encoding/decoding for future persistence
enum Difficulty: String, CaseIterable, Codable {
    case easy = "Easy"
    case medium = "Medium"
    case hard = "Hard"
}

/// Represents a single quiz question with multiple choice answers
/// Each question has exactly 4 answers with one correct answer
struct Question: Identifiable, Hashable {
    let id: UUID
    let text: String
    let answers: [String]        // Exactly 4 answer options
    let correctIndex: Int        // Index (0-3) of the correct answer
    let difficulty: Difficulty
    
    /// Initialize a new question with validation
    init(id: UUID = UUID(), text: String, answers: [String], correctIndex: Int, difficulty: Difficulty) {
        self.id = id
        self.text = text
        self.answers = answers
        self.correctIndex = correctIndex
        self.difficulty = difficulty
    }
}

/// Static question bank containing cooking and food-related quiz questions
struct QuestionBank {
    /// Returns a collection of sample cooking quiz questions
    /// - Returns: Array of Question objects covering various cooking topics and difficulty levels
    static func sampleQuestions() -> [Question] {
        return [
            Question(
                text: "What is the main ingredient in traditional hummus?",
                answers: ["Lentils", "Chickpeas", "Black beans", "Kidney beans"],
                correctIndex: 1,
                difficulty: .easy
            ),
            Question(
                text: "At what temperature does water boil at sea level?",
                answers: ["90°C / 194°F", "100°C / 212°F", "110°C / 230°F", "120°C / 248°F"],
                correctIndex: 1,
                difficulty: .easy
            ),
            Question(
                text: "Which herb is the main ingredient in pesto sauce?",
                answers: ["Parsley", "Cilantro", "Basil", "Oregano"],
                correctIndex: 2,
                difficulty: .easy
            ),
            Question(
                text: "What type of pasta is shaped like small rice grains?",
                answers: ["Orzo", "Penne", "Fusilli", "Farfalle"],
                correctIndex: 0,
                difficulty: .medium
            ),
            Question(
                text: "Which cooking method uses dry heat in an oven?",
                answers: ["Braising", "Poaching", "Roasting", "Steaming"],
                correctIndex: 2,
                difficulty: .easy
            ),
            Question(
                text: "What is the French term for 'put in place' or prepping ingredients?",
                answers: ["Sauté", "Mise en place", "Julienne", "Flambé"],
                correctIndex: 1,
                difficulty: .medium
            ),
            Question(
                text: "Which vitamin is most abundant in citrus fruits?",
                answers: ["Vitamin A", "Vitamin B12", "Vitamin C", "Vitamin D"],
                correctIndex: 2,
                difficulty: .easy
            ),
            Question(
                text: "What is the name of the Japanese cooking technique of grilling with charcoal?",
                answers: ["Tempura", "Yakitori", "Sashimi", "Teriyaki"],
                correctIndex: 1,
                difficulty: .medium
            ),
            Question(
                text: "Which thickening agent is made from corn?",
                answers: ["Arrowroot", "Cornstarch", "Gelatin", "Agar"],
                correctIndex: 1,
                difficulty: .easy
            ),
            Question(
                text: "What is the primary difference between baking powder and baking soda?",
                answers: [
                    "Baking powder contains an acid, baking soda doesn't",
                    "Baking soda contains an acid, baking powder doesn't",
                    "They are the same thing",
                    "Baking powder is only for cakes"
                ],
                correctIndex: 0,
                difficulty: .hard
            ),
            Question(
                text: "Which cheese is traditionally used in a Greek salad?",
                answers: ["Mozzarella", "Cheddar", "Feta", "Parmesan"],
                correctIndex: 2,
                difficulty: .easy
            ),
            Question(
                text: "What is the ideal internal temperature for cooked chicken?",
                answers: ["145°F / 63°C", "155°F / 68°C", "165°F / 74°C", "175°F / 79°C"],
                correctIndex: 2,
                difficulty: .medium
            ),
            Question(
                text: "Which spice is known as the most expensive in the world by weight?",
                answers: ["Vanilla", "Cardamom", "Saffron", "Cinnamon"],
                correctIndex: 2,
                difficulty: .hard
            ),
            Question(
                text: "What does it mean to 'cream' butter and sugar?",
                answers: [
                    "Melt them together",
                    "Beat them until light and fluffy",
                    "Mix them with cream",
                    "Freeze them together"
                ],
                correctIndex: 1,
                difficulty: .medium
            ),
            Question(
                text: "Which type of oil has the highest smoke point?",
                answers: ["Olive oil", "Butter", "Avocado oil", "Coconut oil"],
                correctIndex: 2,
                difficulty: .hard
            )
        ]
    }
}
