//
//  FinalResultsView.swift
//  FamilyCookoffTv
//
//  Final results screen for Family Cook-Off.
//  Displays winner, final scores, and options to play again or return home.
//

import SwiftUI

struct FinalResultsView: View {
    @EnvironmentObject var game: GameViewModel
    @Environment(\.dismiss) var dismiss
    
    // Computed property for sorted players
    private var sortedPlayers: [Player] {
        game.players.sorted { $0.score > $1.score }
    }
    
    // Winner (player with highest score)
    private var winner: Player? {
        sortedPlayers.first
    }
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.purple.opacity(0.3),
                    Color.pink.opacity(0.3),
                    Color.orange.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 50) {
                    // Title
                    Text("Family Cook-Off Results")
                        .font(.system(size: 70, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                        .padding(.top, 40)
                    
                    // Winner announcement
                    if let winner = winner {
                        winnerSection(winner: winner)
                    }
                    
                    // All players results
                    resultsSection
                    
                    // Action buttons
                    actionButtons
                }
                .padding(.horizontal, 80)
                .padding(.bottom, 60)
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    // MARK: - Winner Section
    
    private func winnerSection(winner: Player) -> some View {
        VStack(spacing: 25) {
            // Trophy and crown icons
            HStack(spacing: 20) {
                Image(systemName: "trophy.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Image(systemName: "crown.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Image(systemName: "trophy.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
            
            Text("🎉 Winner! 🎉")
                .font(.system(size: 60, weight: .bold))
                .foregroundColor(.orange)
            
            // Winner's details
            VStack(spacing: 15) {
                Image(systemName: winner.avatarSymbolName)
                    .font(.system(size: 100))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Text(winner.name)
                    .font(.system(size: 55, weight: .bold))
                    .foregroundColor(.primary)
                
                HStack(spacing: 15) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 35))
                    Text("\(winner.score) Points")
                        .font(.system(size: 45, weight: .semibold))
                }
                .foregroundColor(.orange)
            }
            .padding(40)
            .background(
                RoundedRectangle(cornerRadius: 25)
                    .fill(
                        LinearGradient(
                            colors: [.yellow.opacity(0.2), .orange.opacity(0.2)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 25)
                    .stroke(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 4
                    )
            )
        }
    }
    
    // MARK: - Results Section
    
    private var resultsSection: some View {
        VStack(spacing: 25) {
            Text("Final Standings")
                .font(.system(size: 45, weight: .semibold))
                .foregroundColor(.primary)
            
            VStack(spacing: 20) {
                ForEach(Array(sortedPlayers.enumerated()), id: \.element.id) { index, player in
                    ResultCard(
                        player: player,
                        position: index + 1,
                        isWinner: player.id == winner?.id
                    )
                }
            }
        }
    }
    
    // MARK: - Action Buttons
    
    private var actionButtons: some View {
        HStack(spacing: 40) {
            // Play Again button - NavigationLink to new game
            NavigationLink(destination: GameRoundView()
                .onAppear {
                    game.resetGameKeepingPlayers()
                }
            ) {
                VStack(spacing: 15) {
                    Image(systemName: "arrow.clockwise.circle.fill")
                        .font(.system(size: 50))
                    Text("Play Again")
                        .font(.system(size: 38, weight: .semibold))
                }
                .frame(width: 350, height: 150)
                .background(
                    LinearGradient(
                        colors: [.green, .blue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(20)
            }
            .buttonStyle(.card)
            
            // Back to Home button - NavigationLink to welcome
            NavigationLink(destination: WelcomeView()
                .onAppear {
                    game.resetAll()
                }
            ) {
                VStack(spacing: 15) {
                    Image(systemName: "house.circle.fill")
                        .font(.system(size: 50))
                    Text("Back to Home")
                        .font(.system(size: 38, weight: .semibold))
                }
                .frame(width: 350, height: 150)
                .background(
                    LinearGradient(
                        colors: [.orange, .pink],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(20)
            }
            .buttonStyle(.card)
        }
        .padding(.top, 20)
    }
}

// MARK: - Result Card Component

struct ResultCard: View {
    let player: Player
    let position: Int
    let isWinner: Bool
    
    // Medal emoji for top 3
    private var positionBadge: String {
        switch position {
        case 1: return "🥇"
        case 2: return "🥈"
        case 3: return "🥉"
        default: return "\(position)"
        }
    }
    
    var body: some View {
        HStack(spacing: 30) {
            // Position badge
            Text(positionBadge)
                .font(.system(size: position <= 3 ? 50 : 40, weight: .bold))
                .frame(width: 80)
            
            // Crown icon for winner
            if isWinner {
                Image(systemName: "crown.fill")
                    .font(.system(size: 40))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.yellow, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
            
            // Player avatar
            Image(systemName: player.avatarSymbolName)
                .font(.system(size: 45))
                .foregroundStyle(
                    isWinner ?
                    LinearGradient(
                        colors: [.yellow, .orange],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ) : LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 80)
            
            // Player name
            VStack(alignment: .leading, spacing: 5) {
                Text(player.name)
                    .font(.system(size: 36, weight: isWinner ? .bold : .semibold))
                    .foregroundColor(.primary)
                
                HStack(spacing: 5) {
                    Image(systemName: "heart.fill")
                        .font(.system(size: 18))
                    Text(player.favouriteIngredient)
                        .font(.system(size: 22))
                }
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Score
            HStack(spacing: 10) {
                Image(systemName: "star.fill")
                    .font(.system(size: 28))
                Text("\(player.score)")
                    .font(.system(size: 42, weight: .bold))
            }
            .foregroundColor(isWinner ? .orange : .blue)
            .padding(.horizontal, 25)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(isWinner ? Color.orange.opacity(0.2) : Color.blue.opacity(0.1))
            )
        }
        .padding(30)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(isWinner ? Color.yellow.opacity(0.15) : Color.secondary.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(isWinner ? Color.orange : Color.clear, lineWidth: isWinner ? 3 : 0)
        )
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        FinalResultsView()
            .environmentObject({
                let vm = GameViewModel()
                
                // Add players with scores
                vm.addPlayer(name: "Alice", avatarSymbolName: "fork.knife", favouriteIngredient: "Tomato")
                vm.addPlayer(name: "Bob", avatarSymbolName: "flame.fill", favouriteIngredient: "Cheese")
                vm.addPlayer(name: "Charlie", avatarSymbolName: "leaf.fill", favouriteIngredient: "Basil")
                vm.addPlayer(name: "Diana", avatarSymbolName: "takeoutbag.and.cup.and.straw.fill", favouriteIngredient: "Garlic")
                
                // Manually set scores for preview
                vm.players[0].score = 80  // Alice - Winner
                vm.players[1].score = 60  // Bob
                vm.players[2].score = 40  // Charlie
                vm.players[3].score = 30  // Diana
                
                return vm
            }())
    }
}
