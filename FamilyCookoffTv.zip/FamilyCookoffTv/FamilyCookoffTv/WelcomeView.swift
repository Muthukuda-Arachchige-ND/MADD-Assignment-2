//
//  WelcomeView.swift
//  FamilyCookoffTv
//
//  Welcome screen for Family Cook-Off game.
//  Features large TV-friendly layout with navigation to game setup.
//

import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject var game: GameViewModel
    @State private var showHowToPlay = false
    
    var body: some View {
        ZStack {
            // Background gradient that works in light and dark mode
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.orange.opacity(0.3),
                    Color.pink.opacity(0.3),
                    Color.purple.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 60) {
                Spacer()
                
                // Title Section
                VStack(spacing: 20) {
                    // Chef hat icon
                    Image(systemName: "chef.hat.fill")
                        .font(.system(size: 120))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.orange, .pink],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    
                    Text("Family Cook-Off")
                        .font(.system(size: 80, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                    
                    Text("Multiplayer recipe quiz for your living room")
                        .font(.system(size: 36, weight: .medium))
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 100)
                }
                
                Spacer()
                
                // Button Section
                VStack(spacing: 30) {
                    // Primary button - Start New Game
                    NavigationLink {
                        PlayerSetupView()
                    } label: {
                        HStack(spacing: 15) {
                            Image(systemName: "play.circle.fill")
                                .font(.system(size: 40))
                            Text("Start New Game")
                                .font(.system(size: 42, weight: .semibold))
                        }
                        .frame(width: 600, height: 100)
                        .background(
                            LinearGradient(
                                colors: [.orange, .pink],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(20)
                    }
                    .buttonStyle(.card)
                    
                    // Secondary button - How to Play
                    Button(action: {
                        showHowToPlay = true
                    }) {
                        HStack(spacing: 15) {
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size: 40))
                            Text("How to Play")
                                .font(.system(size: 42, weight: .semibold))
                        }
                        .frame(width: 600, height: 100)
                        .background(Color.secondary.opacity(0.2))
                        .foregroundColor(.primary)
                        .cornerRadius(20)
                    }
                    .buttonStyle(.card)
                }
                
                Spacer()
            }
            .padding(80)
        }
        .sheet(isPresented: $showHowToPlay) {
            HowToPlayView()
        }
    }
}

// MARK: - How to Play Sheet

/// Sheet view displaying game instructions
struct HowToPlaySheet: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            // Background
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.purple.opacity(0.2),
                    Color.blue.opacity(0.2)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 50) {
                // Header
                HStack {
                    Image(systemName: "book.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.blue)
                    
                    Text("How to Play")
                        .font(.system(size: 70, weight: .bold, design: .rounded))
                }
                .padding(.top, 60)
                
                // Instructions
                VStack(alignment: .leading, spacing: 40) {
                    InstructionRow(
                        icon: "person.3.fill",
                        title: "Add Players",
                        description: "Set up 2-4 players with names and avatars"
                    )
                    
                    InstructionRow(
                        icon: "questionmark.circle.fill",
                        title: "Answer Questions",
                        description: "Take turns answering cooking quiz questions"
                    )
                    
                    InstructionRow(
                        icon: "star.fill",
                        title: "Earn Points",
                        description: "Get 10 points for each correct answer"
                    )
                    
                    InstructionRow(
                        icon: "trophy.fill",
                        title: "Win the Game",
                        description: "Player with the most points after 10 rounds wins!"
                    )
                }
                .padding(.horizontal, 120)
                
                Spacer()
                
                // Close button
                Button(action: {
                    dismiss()
                }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 35))
                        Text("Got It!")
                            .font(.system(size: 40, weight: .semibold))
                    }
                    .frame(width: 400, height: 90)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                }
                .buttonStyle(.card)
                .padding(.bottom, 60)
            }
        }
    }
}

// MARK: - Instruction Row Component

/// Reusable instruction row component for How to Play sheet
struct InstructionRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 30) {
            Image(systemName: icon)
                .font(.system(size: 50))
                .foregroundColor(.blue)
                .frame(width: 80)
            
            VStack(alignment: .leading, spacing: 10) {
                Text(title)
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.system(size: 30))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
    }
}

// MARK: - Preview

#Preview {
    WelcomeView()
        .environmentObject(GameViewModel())
}
