//
//  FamilyCookoffTvApp.swift
//  FamilyCookoffTv
//
//  App entry point for Family Cook-Off tvOS game.
//  Creates GameViewModel and provides it to all views via environment.
//

import SwiftUI

@main
struct FamilyCookoffTvApp: App {
    /// Single source of truth for game state, shared across all views
    @StateObject private var game = GameViewModel()
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                WelcomeView()
            }
            .environmentObject(game)
        }
    }
}
