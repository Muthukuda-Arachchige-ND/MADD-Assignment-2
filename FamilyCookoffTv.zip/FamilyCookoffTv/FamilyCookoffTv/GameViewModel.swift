//
//  GameViewModel.swift
//  FamilyCookoffTv
//
//  View model managing the game state and logic for Family Cook-Off.
//  Handles player management, question flow, scoring, and game progression.
//

import Foundation
import Combine

/// Main view model for managing the Family Cook-Off game state
/// ObservableObject: enables SwiftUI views to react to state changes
class GameViewModel: ObservableObject {
    
    // MARK: - Published Properties
    
    /// List of all players participating in the game
    @Published var players: [Player] = []
    
    /// Index of the player whose turn it is currently (0-based)
    @Published var currentPlayerIndex: Int = 0
    
    /// Index of the current question being asked (0-based)
    @Published var currentQuestionIndex: Int = 0
    
    /// Array of questions loaded for the current game session
    @Published var questions: [Question] = []
    
    /// Flag indicating if the game is currently in progress
    @Published var isGameActive: Bool = false
    
    /// Maximum number of rounds/questions to play per game
    @Published var maxRounds: Int = 10
    
    /// Flag indicating if the game has finished (all rounds completed)
    @Published var hasGameFinished: Bool = false
    
    // MARK: - Computed Properties
    
    /// Returns the player whose turn it is currently
    /// - Returns: Current Player object, or nil if no players exist
    var currentPlayer: Player? {
        guard !players.isEmpty && currentPlayerIndex < players.count else {
            return nil
        }
        return players[currentPlayerIndex]
    }
    
    /// Returns the question currently being displayed
    /// - Returns: Current Question object, or nil if no questions loaded
    var currentQuestion: Question? {
        guard !questions.isEmpty && currentQuestionIndex < questions.count else {
            return nil
        }
        return questions[currentQuestionIndex]
    }
    
    // MARK: - Player Management Methods
    
    /// Adds a new player to the game
    /// - Parameters:
    ///   - name: Player's display name
    ///   - avatarSymbolName: SF Symbol name for the player's avatar
    ///   - favouriteIngredient: Player's favorite cooking ingredient
    func addPlayer(name: String, avatarSymbolName: String, favouriteIngredient: String) {
        let newPlayer = Player(
            name: name,
            avatarSymbolName: avatarSymbolName,
            favouriteIngredient: favouriteIngredient,
            score: 0
        )
        players.append(newPlayer)
    }
    
    /// Removes a player from the game
    /// - Parameter player: The player to remove
    func removePlayer(_ player: Player) {
        players.removeAll { $0.id == player.id }
    }
    
    // MARK: - Game Control Methods
    
    /// Checks if the game can be started with the current player count
    /// - Returns: True if player count is between 2 and 4 (inclusive)
    func canStartGame() -> Bool {
        return players.count >= 2 && players.count <= 4
    }
    
    /// Starts a new game session
    /// Resets all scores, loads questions from QuestionBank, and activates the game
    func startGame() {
        guard canStartGame() else { return }
        
        // Reset all player scores to 0
        for index in players.indices {
            players[index].score = 0
        }
        
        // Load questions from the question bank and shuffle them
        var allQuestions = QuestionBank.sampleQuestions()
        allQuestions.shuffle()
        
        // Take only the number of questions needed for maxRounds
        questions = Array(allQuestions.prefix(maxRounds))
        
        // Reset game state
        currentPlayerIndex = 0
        currentQuestionIndex = 0
        isGameActive = true
        hasGameFinished = false
    }
    
    /// Processes a player's answer submission
    /// Awards points if correct, then advances to next player and question
    /// - Parameter answerIndex: The index (0-3) of the selected answer
    func submitAnswer(_ answerIndex: Int) {
        guard isGameActive,
              let question = currentQuestion,
              answerIndex >= 0 && answerIndex < question.answers.count else {
            return
        }
        
        // Check if answer is correct and award points
        if answerIndex == question.correctIndex {
            players[currentPlayerIndex].score += 10
        }
        
        // Advance to next player (round-robin)
        currentPlayerIndex = (currentPlayerIndex + 1) % players.count
        
        // If we've cycled back to first player, move to next question
        if currentPlayerIndex == 0 {
            currentQuestionIndex += 1
        }
        
        // Check if game should end (all questions answered or max rounds reached)
        if currentQuestionIndex >= questions.count || currentQuestionIndex >= maxRounds {
            endGame()
        }
    }
    
    /// Ends the current game and marks it as finished
    private func endGame() {
        isGameActive = false
        hasGameFinished = true
    }
    
    /// Resets the game state while keeping all players and their profiles
    /// Useful for starting a new round with the same players
    func resetGameKeepingPlayers() {
        // Reset scores for all players
        for index in players.indices {
            players[index].score = 0
        }
        
        // Reset game state
        currentPlayerIndex = 0
        currentQuestionIndex = 0
        questions = []
        isGameActive = false
        hasGameFinished = false
    }
    
    /// Completely resets the game to initial state
    /// Clears all players, questions, and returns to welcome screen
    func resetAll() {
        players.removeAll()
        questions.removeAll()
        currentPlayerIndex = 0
        currentQuestionIndex = 0
        isGameActive = false
        hasGameFinished = false
    }
}
