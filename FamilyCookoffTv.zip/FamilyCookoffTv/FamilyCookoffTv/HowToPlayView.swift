//
//  HowToPlayView.swift
//  FamilyCookoffTv
//
//  Instructions screen for Family Cook-Off.
//  Explains game rules and how to play.
//

import SwiftUI

struct HowToPlayView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.purple.opacity(0.2),
                    Color.blue.opacity(0.2),
                    Color.cyan.opacity(0.2)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 50) {
                    // Title with icon
                    HStack(spacing: 20) {
                        Image(systemName: "book.fill")
                            .font(.system(size: 70))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.blue, .purple],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                        
                        Text("How to Play")
                            .font(.system(size: 75, weight: .bold, design: .rounded))
                            .foregroundColor(.primary)
                    }
                    .padding(.top, 50)
                    
                    // Instructions content
                    VStack(spacing: 45) {
                        InstructionStep(
                            number: 1,
                            icon: "person.3.fill",
                            title: "Create Player Profiles",
                            description: "Add 2 to 4 players with names, avatars, and favorite ingredients. Each player gets their own profile!"
                        )
                        
                        InstructionStep(
                            number: 2,
                            icon: "arrow.triangle.turn.up.right.circle.fill",
                            title: "Take Turns",
                            description: "Players take turns answering cooking quiz questions. Each round, one player answers while others watch and cheer!"
                        )
                        
                        InstructionStep(
                            number: 3,
                            icon: "questionmark.circle.fill",
                            title: "Answer Questions",
                            description: "Choose from 4 multiple choice answers. Questions cover cooking techniques, ingredients, temperatures, and culinary knowledge."
                        )
                        
                        InstructionStep(
                            number: 4,
                            icon: "star.fill",
                            title: "Earn Points",
                            description: "Get 10 points for each correct answer! Wrong answers give 0 points, but you'll see the correct answer."
                        )
                        
                        InstructionStep(
                            number: 5,
                            icon: "trophy.fill",
                            title: "Win the Game",
                            description: "After 10 rounds, the player with the most points wins! Celebrate the champion chef and play again!"
                        )
                    }
                    .padding(.horizontal, 80)
                    
                    // Additional game info
                    VStack(spacing: 20) {
                        Divider()
                            .background(Color.secondary)
                            .padding(.horizontal, 100)
                        
                        VStack(spacing: 15) {
                            HStack(spacing: 12) {
                                Image(systemName: "lightbulb.fill")
                                    .font(.system(size: 28))
                                    .foregroundColor(.yellow)
                                Text("Tip:")
                                    .font(.system(size: 32, weight: .bold))
                                    .foregroundColor(.primary)
                            }
                            
                            Text("Questions have different difficulty levels: Easy, Medium, and Hard. All questions are worth the same points!")
                                .font(.system(size: 28))
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 60)
                        }
                    }
                    .padding(.top, 20)
                    
                    // Close button
                    Button(action: {
                        dismiss()
                    }) {
                        HStack(spacing: 15) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 40))
                            Text("Close")
                                .font(.system(size: 42, weight: .semibold))
                        }
                        .frame(width: 400, height: 100)
                        .background(
                            LinearGradient(
                                colors: [.blue, .purple],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(20)
                    }
                    .buttonStyle(.card)
                    .padding(.top, 20)
                    .padding(.bottom, 60)
                }
            }
        }
    }
}

// MARK: - Instruction Step Component

struct InstructionStep: View {
    let number: Int
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 30) {
            // Step number badge
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 80, height: 80)
                
                Text("\(number)")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.white)
            }
            
            // Icon
            Image(systemName: icon)
                .font(.system(size: 55))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 80)
            
            // Text content
            VStack(alignment: .leading, spacing: 12) {
                Text(title)
                    .font(.system(size: 38, weight: .bold))
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.system(size: 30))
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            
            Spacer()
        }
        .padding(35)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.6))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.blue.opacity(0.3), lineWidth: 2)
        )
    }
}

// MARK: - Preview

#Preview {
    HowToPlayView()
}
