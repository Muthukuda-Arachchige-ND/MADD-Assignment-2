//
//  GameRoundView.swift
//  FamilyCookoffTv
//
//  Main quiz gameplay screen for Family Cook-Off.
//  Players take turns answering cooking questions.
//

import SwiftUI

struct GameRoundView: View {
    @EnvironmentObject var game: GameViewModel
    
    // State for answer feedback
    @State private var showFeedback = false
    @State private var isCorrectAnswer = false
    @State private var correctAnswerText = ""
    @State private var selectedAnswerIndex: Int?
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.green.opacity(0.2),
                    Color.blue.opacity(0.2),
                    Color.purple.opacity(0.2)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            if game.hasGameFinished {
                // Game finished - navigate to results
                VStack(spacing: 30) {
                    Text("Game Over!")
                        .font(.system(size: 70, weight: .bold))
                    
                    NavigationLink(destination: FinalResultsView()) {
                        HStack(spacing: 15) {
                            Image(systemName: "trophy.fill")
                                .font(.system(size: 40))
                            Text("View Results")
                                .font(.system(size: 40, weight: .semibold))
                        }
                        .padding(.horizontal, 60)
                        .padding(.vertical, 30)
                        .background(
                            LinearGradient(
                                colors: [.orange, .pink],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(15)
                    }
                    .buttonStyle(.card)
                }
            } else if let currentQuestion = game.currentQuestion {
                // Main game content
                VStack(spacing: 40) {
                    // Top section - Round info, current player, scoreboard
                    topSection
                    
                    Spacer()
                    
                    // Middle section - Question and answers
                    questionSection(question: currentQuestion)
                    
                    Spacer()
                }
                .padding(60)
                .animation(.easeInOut, value: game.currentQuestionIndex)
                
                // Feedback overlay
                if showFeedback {
                    feedbackOverlay
                }
            } else {
                // Loading or no questions
                VStack(spacing: 30) {
                    ProgressView()
                        .scaleEffect(2)
                    Text("Loading questions...")
                        .font(.system(size: 40))
                        .foregroundColor(.secondary)
                }
            }
        }
        .onAppear {
            // Start the game when this view appears
            if !game.isGameActive {
                game.startGame()
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    // MARK: - Top Section
    
    private var topSection: some View {
        VStack(spacing: 20) {
            // Round counter
            Text("Round \(game.currentQuestionIndex + 1) of \(game.maxRounds)")
                .font(.system(size: 36, weight: .semibold))
                .foregroundColor(.secondary)
            
            // Current player
            if let currentPlayer = game.currentPlayer {
                HStack(spacing: 15) {
                    Image(systemName: currentPlayer.avatarSymbolName)
                        .font(.system(size: 50))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.orange, .pink],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    
                    Text("Now Playing: \(currentPlayer.name)")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundColor(.primary)
                }
            }
            
            // Scoreboard
            scoreboard
        }
    }
    
    // MARK: - Scoreboard
    
    private var scoreboard: some View {
        HStack(spacing: 15) {
            ForEach(game.players) { player in
                ScoreCard(
                    player: player,
                    isCurrentPlayer: player.id == game.currentPlayer?.id
                )
            }
        }
        .padding(.top, 10)
    }
    
    // MARK: - Question Section
    
    private func questionSection(question: Question) -> some View {
        VStack(spacing: 40) {
            // Question text
            VStack(spacing: 15) {
                // Difficulty badge
                HStack(spacing: 10) {
                    Image(systemName: difficultyIcon(question.difficulty))
                        .font(.system(size: 24))
                    Text(question.difficulty.rawValue)
                        .font(.system(size: 26, weight: .semibold))
                }
                .foregroundColor(difficultyColor(question.difficulty))
                .padding(.horizontal, 25)
                .padding(.vertical, 10)
                .background(difficultyColor(question.difficulty).opacity(0.2))
                .cornerRadius(20)
                
                Text(question.text)
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 60)
                    .fixedSize(horizontal: false, vertical: true)
            }
            
            // Answer options (2x2 grid)
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 20),
                GridItem(.flexible(), spacing: 20)
            ], spacing: 20) {
                ForEach(Array(question.answers.enumerated()), id: \.offset) { index, answer in
                    AnswerButton(
                        text: answer,
                        index: index,
                        isSelected: selectedAnswerIndex == index,
                        action: {
                            selectAnswer(index)
                        }
                    )
                }
            }
            .disabled(showFeedback)
        }
    }
    
    // MARK: - Feedback Overlay
    
    private var feedbackOverlay: some View {
        ZStack {
            // Semi-transparent background
            Color.black.opacity(0.7)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                // Icon
                Image(systemName: isCorrectAnswer ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .font(.system(size: 120))
                    .foregroundColor(isCorrectAnswer ? .green : .red)
                
                // Feedback text
                Text(isCorrectAnswer ? "Correct!" : "Wrong!")
                    .font(.system(size: 70, weight: .bold))
                    .foregroundColor(.white)
                
                if isCorrectAnswer {
                    Text("+10 Points")
                        .font(.system(size: 50, weight: .semibold))
                        .foregroundColor(.green)
                } else {
                    VStack(spacing: 10) {
                        Text("Correct answer:")
                            .font(.system(size: 35))
                            .foregroundColor(.white.opacity(0.8))
                        
                        Text(correctAnswerText)
                            .font(.system(size: 45, weight: .semibold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 60)
                    }
                }
            }
            .padding(80)
            .background(
                RoundedRectangle(cornerRadius: 30)
                    .fill(isCorrectAnswer ? Color.green.opacity(0.2) : Color.red.opacity(0.2))
            )
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    // MARK: - Helper Methods
    
    private func selectAnswer(_ index: Int) {
        guard let question = game.currentQuestion else { return }
        
        selectedAnswerIndex = index
        isCorrectAnswer = (index == question.correctIndex)
        correctAnswerText = question.answers[question.correctIndex]
        
        // Submit answer to game logic
        game.submitAnswer(index)
        
        // Show feedback
        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
            showFeedback = true
        }
        
        // Hide feedback and move to next question after delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            withAnimation(.easeOut(duration: 0.3)) {
                showFeedback = false
                selectedAnswerIndex = nil
            }
        }
    }
    
    private func difficultyIcon(_ difficulty: Difficulty) -> String {
        switch difficulty {
        case .easy: return "star.fill"
        case .medium: return "star.leadinghalf.filled"
        case .hard: return "flame.fill"
        }
    }
    
    private func difficultyColor(_ difficulty: Difficulty) -> Color {
        switch difficulty {
        case .easy: return .green
        case .medium: return .orange
        case .hard: return .red
        }
    }
}

// MARK: - Score Card Component

struct ScoreCard: View {
    let player: Player
    let isCurrentPlayer: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: player.avatarSymbolName)
                .font(.system(size: 30))
                .foregroundStyle(
                    isCurrentPlayer ?
                    LinearGradient(
                        colors: [.orange, .pink],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ) : LinearGradient(
                        colors: [.gray],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
            
            Text(player.name)
                .font(.system(size: 22, weight: isCurrentPlayer ? .bold : .regular))
                .foregroundColor(isCurrentPlayer ? .primary : .secondary)
            
            Text("\(player.score)")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(isCurrentPlayer ? .orange : .secondary)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 15)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(isCurrentPlayer ? Color.orange.opacity(0.2) : Color.secondary.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(isCurrentPlayer ? Color.orange : Color.clear, lineWidth: 3)
        )
        .scaleEffect(isCurrentPlayer ? 1.05 : 1.0)
        .animation(.easeInOut, value: isCurrentPlayer)
    }
}

// MARK: - Answer Button Component

struct AnswerButton: View {
    let text: String
    let index: Int
    let isSelected: Bool
    let action: () -> Void
    
    // Letter labels for answers
    private let labels = ["A", "B", "C", "D"]
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 20) {
                // Letter label
                Text(labels[index])
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 60, height: 60)
                    .background(
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: isSelected ? [.green, .teal] : [.purple, .indigo],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    )
                
                // Answer text
                Text(text)
                    .font(.system(size: 32, weight: .semibold))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(25)
            .frame(height: 120)
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(
                        Color.white
                            .opacity(isSelected ? 1.0 : 0.9)
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(
                        isSelected ? Color.green.opacity(0.9) : Color.white.opacity(0.2),
                        lineWidth: isSelected ? 3 : 1.5
                    )
            )
        }
        .buttonStyle(.card)
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        GameRoundView()
            .environmentObject({
                let vm = GameViewModel()
                // Add players
                vm.addPlayer(name: "Alice", avatarSymbolName: "fork.knife", favouriteIngredient: "Tomato")
                vm.addPlayer(name: "Bob", avatarSymbolName: "flame.fill", favouriteIngredient: "Cheese")
                vm.addPlayer(name: "Charlie", avatarSymbolName: "leaf.fill", favouriteIngredient: "Basil")
                
                // Start the game to load questions
                vm.startGame()
                
                return vm
            }())
    }
}
