import Foundation

struct Recipe: Identifiable, Hashable {
    let id: UUID
    let title: String
    let description: String
    let ingredients: [String]
    let steps: [String]
    let timeMinutes: Int
    /// Difficulty level, e.g. "Easy", "Medium", "Hard".
    let difficulty: String

    init(
        id: UUID = UUID(),
        title: String,
        description: String,
        ingredients: [String],
        steps: [String],
        timeMinutes: Int,
        difficulty: String = "Medium"
    ) {
        self.id = id
        self.title = title
        self.description = description
        self.ingredients = ingredients
        self.steps = steps
        self.timeMinutes = timeMinutes
        self.difficulty = difficulty
    }
}

struct RecipeGenerator {

    // MARK: - AI-backed generation

    /// Try to generate recipes using an external AI API; if that fails, fall back to a local generator.
    static func generateAI(for ingredient: String) async -> [Recipe] {
        // Try AI first if an API key is configured
        if let key = Bundle.main.infoDictionary?["OPENAI_API_KEY"] as? String,
           !key.isEmpty {
            do {
                let aiRecipes = try await fetchAIRecipes(for: ingredient)
                if !aiRecipes.isEmpty {
                    return aiRecipes
                }
            } catch {
                print("AI recipe generation failed: \(error)")
            }
        } else {
            print("OPENAI_API_KEY not set; using local recipe generator.")
        }

        // Local programmatic generator (not ML) so the UI always has recipes to show
        return generateLocalRecipes(for: ingredient)
    }

    private static func generateLocalRecipes(for ingredient: String) -> [Recipe] {
        let base = ingredient.capitalized
        let lower = ingredient.lowercased()
        return [
            Recipe(
                title: "\(base) Salad",
                description: "A quick fresh salad using chopped \(lower) with a simple dressing.",
                ingredients: [
                    "1 cup chopped \(lower)",
                    "1 tbsp olive oil",
                    "1 tsp lemon juice",
                    "Salt",
                    "Pepper"
                ],
                steps: [
                    "Combine \(lower), olive oil, and lemon juice in a bowl.",
                    "Season with salt and pepper.",
                    "Serve immediately."
                ],
                timeMinutes: 10,
                difficulty: "Easy"
            ),
            Recipe(
                title: "\(base) Stir-Fry",
                description: "Simple pan-fried \(lower) with garlic and soy sauce.",
                ingredients: [
                    "1 cup sliced \(lower)",
                    "1 tbsp oil",
                    "1 clove garlic, minced",
                    "1 tbsp soy sauce"
                ],
                steps: [
                    "Heat oil in a pan and add garlic.",
                    "Add \(lower) and stir-fry 3–4 minutes.",
                    "Splash in soy sauce, toss, and serve."
                ],
                timeMinutes: 15,
                difficulty: "Easy"
            ),
            Recipe(
                title: "\(base) Curry",
                description: "A comforting curry featuring \(lower) in a spiced sauce.",
                ingredients: [
                    "2 cups chopped \(lower)",
                    "1 small onion",
                    "1 tbsp curry powder",
                    "1 tbsp oil",
                    "2 cups stock or water",
                    "Salt"
                ],
                steps: [
                    "Sauté onion in oil until soft.",
                    "Add curry powder and cook 1 minute.",
                    "Stir in \(lower) and stock, then simmer until tender.",
                    "Season with salt and serve with rice or bread."
                ],
                timeMinutes: 30,
                difficulty: "Medium"
            ),
            Recipe(
                title: "Baked \(base) Tray",
                description: "Oven-baked \(lower) with herbs and olive oil.",
                ingredients: [
                    "3 cups \(lower), cut into bite-size pieces",
                    "2 tbsp olive oil",
                    "1 tsp dried herbs",
                    "Salt",
                    "Pepper"
                ],
                steps: [
                    "Preheat oven to 220°C.",
                    "Toss \(lower) with oil, herbs, salt, and pepper on a tray.",
                    "Bake 20–25 minutes until browned and tender."
                ],
                timeMinutes: 35,
                difficulty: "Medium"
            ),
            Recipe(
                title: "Gourmet \(base) Feast",
                description: "A more involved main course using \(lower) with multiple cooking steps.",
                ingredients: [
                    "2 cups prepared \(lower)",
                    "1 cup cooked grains or pasta",
                    "1/2 cup cheese or toppings of choice",
                    "Fresh herbs",
                    "Salt",
                    "Pepper"
                ],
                steps: [
                    "Cook grains or pasta according to package instructions.",
                    "Cook or roast \(lower) until tender.",
                    "Combine everything in a baking dish, top with cheese and herbs.",
                    "Bake until the top is golden and bubbling, then serve."
                ],
                timeMinutes: 45,
                difficulty: "Hard"
            )
        ]
    }

    private enum AIRecipeError: Error {
        case missingAPIKey
        case invalidResponse
    }

    private static func fetchAIRecipes(for ingredient: String) async throws -> [Recipe] {
        guard let apiKey = Bundle.main.infoDictionary?["OPENAI_API_KEY"] as? String,
              !apiKey.isEmpty else {
            throw AIRecipeError.missingAPIKey
        }

        guard let url = URL(string: "https://api.openai.com/v1/chat/completions") else {
            throw AIRecipeError.invalidResponse
        }

        let prompt = "Create 5 simple recipes that use \(ingredient.lowercased()) as the main ingredient. For each recipe, include a difficulty field that is exactly one of: easy, medium, hard. Respond ONLY with valid JSON in this exact format: {\"recipes\":[{\"title\":\"...\",\"description\":\"...\",\"timeMinutes\":15,\"difficulty\":\"easy\",\"ingredients\":[\"...\"],\"steps\":[\"...\"]}]}"

        let requestBody = ChatCompletionRequest(
            model: "gpt-4o-mini",
            messages: [
                .init(role: "system", content: "You are a helpful chef AI that returns strictly valid JSON for recipes."),
                .init(role: "user", content: prompt)
            ],
            temperature: 0.7
        )

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw AIRecipeError.invalidResponse
        }

        let chat = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        guard let content = chat.choices.first?.message.content else {
            throw AIRecipeError.invalidResponse
        }

        let jsonData = Data(content.utf8)
        let decoded = try JSONDecoder().decode(AIRecipePayload.self, from: jsonData)
        return decoded.recipes.map { ai in
            Recipe(
                title: ai.title,
                description: ai.description,
                ingredients: ai.ingredients,
                steps: ai.steps,
                timeMinutes: ai.timeMinutes,
                difficulty: ai.difficulty.capitalized
            )
        }
    }

    private struct ChatCompletionRequest: Encodable {
        struct Message: Encodable {
            let role: String
            let content: String
        }
        let model: String
        let messages: [Message]
        let temperature: Double
    }

    private struct ChatCompletionResponse: Decodable {
        struct Choice: Decodable {
            struct Message: Decodable {
                let content: String
            }
            let message: Message
        }
        let choices: [Choice]
    }

    private struct AIRecipePayload: Decodable {
        let recipes: [AIRecipe]
    }

    private struct AIRecipe: Decodable {
        let title: String
        let description: String
        let timeMinutes: Int
        let difficulty: String
        let ingredients: [String]
        let steps: [String]
    }
}
