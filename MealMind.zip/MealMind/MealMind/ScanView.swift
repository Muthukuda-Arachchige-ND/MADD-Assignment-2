import SwiftUI
import PhotosUI

struct ScanView: View {
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImageData: Data? = nil
    @State private var predictedIngredient: String? = nil
    @State private var isAnalyzing: Bool = false
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(.systemBackground),
                    Color(.systemGray6)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    HStack(alignment: .center, spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(LinearGradient(colors: [Color.orange, Color.red], startPoint: .topLeading, endPoint: .bottomTrailing))
                            Image(systemName: "camera.viewfinder")
                                .foregroundStyle(.white)
                                .font(.title2)
                        }
                        .frame(width: 56, height: 56)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Scan a food photo")
                                .font(.headline)
                            Text("Choose a picture and let AI detect the main ingredient.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 4)
                    
                    // Photo picker
                    PhotosPicker(selection: $selectedItem, matching: .images, photoLibrary: .shared()) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text("Select Food Photo")
                        }
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .shadow(radius: 4, y: 2)
                    }
                    .onChange(of: selectedItem) { oldItem, newItem in
                        Task {
                            guard let data = try? await newItem?.loadTransferable(type: Data.self) else { return }
                            selectedImageData = data
                            predictedIngredient = nil
                            isAnalyzing = true
                            let label = await FoodRecognizer.recognize(from: data)
                            predictedIngredient = label ?? "Unknown"
                            isAnalyzing = false
                        }
                    }
                    
                    // Selected image preview
                    Group {
                        if let data = selectedImageData, let uiImage = UIImage(data: data) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .shadow(radius: 4, y: 2)
                        } else {
                            VStack(spacing: 10) {
                                Image(systemName: "photo")
                                    .font(.largeTitle)
                                    .foregroundStyle(.secondary)
                                Text("No image selected")
                                    .font(.headline)
                                Text("Choose a food photo to analyze.")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.thinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                    }
                    
                    // Prediction section
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Predicted Ingredient")
                            .font(.headline)
                        
                        if isAnalyzing {
                            HStack(spacing: 8) {
                                ProgressView()
                                    .progressViewStyle(.circular)
                                Text("Analyzing…")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        } else {
                            Text(predictedIngredient ?? "—")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundStyle(predictedIngredient == nil ? .secondary : .primary)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    
                    // See recipes button
                    NavigationLink {
                        RecipesView(ingredient: predictedIngredient ?? "Ingredient")
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "fork.knife")
                            Text("See Recipes")
                        }
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: [Color.orange, Color.red],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .opacity((predictedIngredient == nil || isAnalyzing) ? 0.4 : 1.0)
                        )
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 6)
                    }
                    .disabled(predictedIngredient == nil || isAnalyzing)
                    
                    Spacer(minLength: 0)
                }
                .padding()
            }
            .navigationTitle("Scan")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ScanView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ScanView()
        }
    }
}
