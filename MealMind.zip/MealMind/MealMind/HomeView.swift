import SwiftUI

struct HomeView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @State private var selectedTab = 0
    @State private var showARScanner = false
    @State private var showPhotoLibrary = false
    @EnvironmentObject private var favoritesManager: FavoritesManager
    
    // Sample data
    @State private var recentScans = ["Apple", "Chicken", "Tomato"]
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                LinearGradient(
                    colors: [
                        Color(.systemBackground),
                        Color(.systemGray6)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                // Main Content
                VStack(spacing: 0) {
                    // Header
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("MealMind")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                            Text("Your personal food assistant")
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        
                        Button(action: {
                            isDarkMode.toggle()
                        }) {
                            Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                                .font(.title3)
                        }
                    }
                    .padding()
                    
                    // Tab Content
                    if selectedTab == 0 {
                        homeTabContent
                    } else {
                        favoritesTabContent
                    }
                    
                    Spacer()
                }
                
                // Bottom Tab Bar
                bottomTabBar
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showARScanner) {
                NavigationStack {
                    ARFoodScannerView()
                }
                .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showPhotoLibrary) {
                NavigationStack {
                    ScanView()
                }
                .presentationDetents([.medium, .large])
            }
        }
    }
    
    // MARK: - View Components
    
    private var heroCard: some View {
        HStack(alignment: .center, spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color.orange, Color.red],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                if let uiImage = UIImage(named: "homeHero") {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 100, height: 80)
                        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                } else {
                    Image(systemName: "fork.knife.circle.fill")
                        .font(.system(size: 32))
                        .foregroundStyle(.white)
                }
            }
            .frame(width: 80, height: 80)
            VStack(alignment: .leading, spacing: 6) {
                Text("What will you cook today?")
                    .font(.headline)
                    .foregroundStyle(.white)
                Text("Scan an ingredient and get instant recipes.")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.9))
            }
            Spacer()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.orange, Color.red],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: Color.black.opacity(0.15), radius: 12, x: 0, y: 8)
    }
    
    private var homeTabContent: some View {
        ScrollView {
            VStack(spacing: 24) {
                heroCard
                // Scan Buttons
                VStack(spacing: 16) {
                    Button(action: { showARScanner = true }) {
                        HStack {
                            Image(systemName: "viewfinder")
                                .font(.title)
                            VStack(alignment: .leading) {
                                Text("Scan Food")
                                    .font(.headline)
                                Text("Use AR to identify ingredients")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(Color.blue.opacity(0.25), lineWidth: 1)
                        )
                        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
                    }
                    
                    Button(action: { showPhotoLibrary = true }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                                .font(.title)
                            VStack(alignment: .leading) {
                                Text("Photo Library")
                                    .font(.headline)
                                Text("Upload food photos")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(Color.green.opacity(0.25), lineWidth: 1)
                        )
                        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
                    }
                }
                .padding(.horizontal)
                
                // Recent Scans
                VStack(alignment: .leading, spacing: 10) {
                    Text("Recent Scans")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(recentScans, id: \.self) { item in
                                VStack(spacing: 8) {
                                    ZStack {
                                        Circle()
                                            .fill(
                                                LinearGradient(
                                                    colors: [Color.green, Color.blue],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                )
                                            )
                                        if let uiImage = UIImage(named: item.lowercased()) {
                                            Image(uiImage: uiImage)
                                                .resizable()
                                                .scaledToFill()
                                                .clipShape(Circle())
                                        }
                                    }
                                    Text(item)
                                        .font(.caption)
                                        .lineLimit(1)
                                }
                                .frame(width: 90)
                                .padding(10)
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 3)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                
                Spacer()
            }
            .padding(.bottom, 80) // Space for tab bar
        }
    }
    
    private var favoritesTabContent: some View {
        List {
            ForEach(favoritesManager.favoriteRecipes) { recipe in
                HStack(alignment: .center, spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [Color.orange, Color.red],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                        Image(systemName: "fork.knife")
                            .foregroundStyle(.white)
                    }
                    .frame(width: 40, height: 40)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(recipe.title)
                            .font(.headline)
                        Text("Saved recipe")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button(action: {
                        favoritesManager.toggleFavorite(recipe)
                    }) {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                    }
                }
                .padding(12)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 3)
                .listRowBackground(Color.clear)
            }
        }
        .scrollContentBackground(.hidden)
        .listStyle(.plain)
        .padding(.bottom, 60) // Space for tab bar
    }
    
    private var bottomTabBar: some View {
        HStack(spacing: 0) {
            tabBarButton(icon: "house", title: "Home", tab: 0)
            tabBarButton(icon: "heart", title: "Favorites", tab: 1)
            
            // Center Add Button
            Button(action: {
                // Show add options
            }) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.blue)
                    .shadow(radius: 3)
                    .offset(y: -20)
            }
            .frame(maxWidth: .infinity)
            
            tabBarButton(icon: "magnifyingglass", title: "Search", tab: 2)
            tabBarButton(icon: "person", title: "Profile", tab: 3)
        }
        .background(
            Color(.systemBackground)
                .shadow(radius: 0.5, y: -0.5)
        )
    }
    
    private func tabBarButton(icon: String, title: String, tab: Int) -> some View {
        Button(action: {
            selectedTab = tab
        }) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 22))
                    .padding(.bottom, 4)
                Text(title)
                    .font(.caption)
            }
            .foregroundColor(selectedTab == tab ? .blue : .gray)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
        }
    }
}

// Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .preferredColorScheme(.dark)
    }
}
