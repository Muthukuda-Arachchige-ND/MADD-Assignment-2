import SwiftUI

struct RecipesView: View {
    let ingredient: String
    @State private var selectedRecipe: Recipe? = nil
    @State private var recipes: [Recipe] = []
    @State private var isLoading: Bool = false
    @State private var selectedDifficulty: DifficultyFilter = .all
    @EnvironmentObject private var favoritesManager: FavoritesManager

    private var filteredRecipes: [Recipe] {
        switch selectedDifficulty {
        case .all:
            return recipes
        case .easy: // 10 min
            return recipes.filter { $0.timeMinutes <= 10 }
        case .medium: // 20 min
            return recipes.filter { $0.timeMinutes > 10 && $0.timeMinutes <= 20 }
        case .hard: // 30+ min
            return recipes.filter { $0.timeMinutes >= 30 }
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(.systemBackground),
                    Color(.systemGray6)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Recipes for")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(ingredient)
                            .font(.largeTitle.bold())
                    }

                    Picker("Time", selection: $selectedDifficulty) {
                        ForEach(DifficultyFilter.allCases) { filter in
                            Text(filter.rawValue).tag(filter)
                        }
                    }
                    .pickerStyle(.segmented)

                    if isLoading && recipes.isEmpty {
                        HStack(spacing: 8) {
                            ProgressView()
                            Text("Generating recipes…")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }

                    if !isLoading && recipes.isEmpty {
                        Text("No recipes available yet. Try again in a moment.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }

                    ForEach(filteredRecipes) { recipe in
                        Button {
                            selectedRecipe = recipe
                        } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack(alignment: .top, spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(LinearGradient(colors: [Color.orange, Color.red], startPoint: .topLeading, endPoint: .bottomTrailing))
                                        if let uiImage = UIImage(named: ingredient.lowercased()) {
                                            Image(uiImage: uiImage)
                                                .resizable()
                                                .scaledToFill()
                                                .clipShape(Circle())
                                        }
                                        Image(systemName: "fork.knife")
                                            .foregroundStyle(.white)
                                            .font(.headline)
                                    }
                                    .frame(width: 40, height: 40)

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(recipe.title)
                                            .font(.headline)

                                        HStack(spacing: 8) {
                                            Label("\(recipe.timeMinutes) min", systemImage: "clock")
                                                .font(.caption2)
                                                .foregroundStyle(.secondary)

                                            Text(timeCategory(for: recipe))
                                                .font(.caption2)
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 2)
                                                .background(
                                                    Capsule()
                                                        .fill(Color.orange.opacity(0.12))
                                                )
                                        }
                                    }
                                    Spacer()
                                    Button(action: {
                                        favoritesManager.toggleFavorite(recipe)
                                    }) {
                                        Image(systemName: favoritesManager.isFavorite(recipe) ? "heart.fill" : "heart")
                                            .foregroundColor(favoritesManager.isFavorite(recipe) ? .red : .secondary)
                                    }
                                }

                                Text(recipe.description)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            .padding()
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 4)
                        }
                    }
                }
                .padding()
            }
        }
        .navigationTitle("Recipes")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await loadRecipes()
        }
        .sheet(item: $selectedRecipe) { recipe in
            RecipeDetailView(recipe: recipe)
        }
    }

    private func loadRecipes() async {
        guard !isLoading else { return }
        isLoading = true
        let result = await RecipeGenerator.generateAI(for: ingredient)
        recipes = result
        isLoading = false
    }
}

#Preview {
    NavigationStack { RecipesView(ingredient: "Tomato") }
}

enum DifficultyFilter: String, CaseIterable, Identifiable {
    case all = "All"
    case easy = "10 min"
    case medium = "20 min"
    case hard = "30+ min"

    var id: String { rawValue }
}

private func timeCategory(for recipe: Recipe) -> String {
    switch recipe.timeMinutes {
    case ...10:
        return "10 min"
    case 11...20:
        return "20 min"
    default:
        return "30+ min"
    }
}

struct RecipeDetailView: View {
    let recipe: Recipe
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(recipe.title)
                        .font(.largeTitle.bold())
                    Text(recipe.description)
                        .foregroundStyle(.secondary)
                    HStack {
                        Label("\(recipe.timeMinutes) min", systemImage: "clock")
                        Text("·")
                            .foregroundStyle(.secondary)
                        Text(timeCategory(for: recipe))
                        Spacer()
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    Divider()
                    Text("Ingredients").font(.headline)
                    ForEach(recipe.ingredients, id: \.self) { item in
                        HStack(alignment: .top) {
                            Text("•")
                            Text(item)
                        }
                    }
                    Divider()
                    Text("Steps").font(.headline)
                    ForEach(Array(recipe.steps.enumerated()), id: \.offset) { idx, step in
                        HStack(alignment: .top) {
                            Text("\(idx+1).")
                                .frame(width: 20, alignment: .trailing)
                            Text(step)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Recipe")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
