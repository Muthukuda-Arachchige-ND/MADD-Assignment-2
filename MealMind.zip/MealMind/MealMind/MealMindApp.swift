//
//  MealMindApp.swift
//  MealMind
//
//  Created by IM Student on 2025-11-16.
//

import SwiftUI

@main
struct MealMindApp: App {

    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = false
    @AppStorage("isDarkMode") private var isDarkMode = false
    @StateObject private var favoritesManager = FavoritesManager()

    var body: some Scene {
        WindowGroup {
            if hasSeenOnboarding {
                // Only HomeView should be inside NavigationStack
                NavigationStack {
                    HomeView()
                        .environmentObject(favoritesManager)
                }
                .environment(\.colorScheme, isDarkMode ? .dark : .light)
            } else {
                // Onboarding is outside NavigationStack
                OnboardingView()
                    .environment(\.colorScheme, isDarkMode ? .dark : .light)
            }
        }
    }
}
