import SwiftUI
import AVFoundation

struct ARFoodScannerView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = ARFoodScannerViewModel()
    
    var body: some View {
        VStack {
            // Header
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "chevron.backward")
                    Text("Back")
                }
                .foregroundColor(.accentColor)
                
                Spacer()
                
                Text("Food Scanner")
                    .font(.headline)
                
                Spacer()
                
                // Spacer to balance layout
                Color.clear.frame(width: 60, height: 1)
            }
            .padding()
            
            // Camera preview
            ZStack {
                CameraPreview()
                    .frame(height: 280)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(radius: 4, y: 2)

                if viewModel.isScanning {
                    ProgressView("Scanning...")
                        .padding(12)
                        .background(Color.black.opacity(0.6))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
            
            // Detected result
            if let food = viewModel.detectedFood {
                VStack(spacing: 8) {
                    Text("Detected Ingredient")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(food)
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .padding()
            } else {
                Text("Point your camera at food and tap Scan")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
            }
            
            Spacer()
            
            // Scan button
            Button(action: {
                if viewModel.isScanning {
                    viewModel.stopScanning()
                } else {
                    viewModel.startScanning()
                }
            }) {
                HStack {
                    Image(systemName: viewModel.isScanning ? "stop.circle.fill" : "camera.fill")
                    Text(viewModel.isScanning ? "Stop Scanning" : "Scan Food")
                }
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(viewModel.isScanning ? Color.red : Color.accentColor)
                .cornerRadius(14)
                .padding(.horizontal)
                .padding(.bottom)
            }
        }
        .navigationBarHidden(true)
    }
}

// MARK: - Camera Preview
private struct CameraPreview: UIViewRepresentable {
    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.startSession()
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) { }

    final class PreviewView: UIView {
        private let session = AVCaptureSession()

        override class var layerClass: AnyClass {
            AVCaptureVideoPreviewLayer.self
        }

        private var previewLayer: AVCaptureVideoPreviewLayer {
            return layer as! AVCaptureVideoPreviewLayer
        }

        func startSession() {
            previewLayer.videoGravity = .resizeAspectFill

            guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let videoInput = try? AVCaptureDeviceInput(device: videoDevice),
                  session.canAddInput(videoInput) else {
                return
            }

            session.beginConfiguration()
            session.addInput(videoInput)
            session.commitConfiguration()

            if !session.isRunning {
                DispatchQueue.global(qos: .userInitiated).async {
                    self.session.startRunning()
                }
            }

            previewLayer.session = session
        }

        deinit {
            if session.isRunning {
                session.stopRunning()
            }
        }
    }
}

struct ARFoodScannerView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ARFoodScannerView()
        }
    }
}
