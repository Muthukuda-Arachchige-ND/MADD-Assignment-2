import Foundation
import Vision
import UIKit
import CoreImage

struct FoodRecognizer {
    private static func cgImageOrientation(from uiImageOrientation: UIImage.Orientation) -> CGImagePropertyOrientation {
        switch uiImageOrientation {
        case .up: return .up
        case .upMirrored: return .upMirrored
        case .down: return .down
        case .downMirrored: return .downMirrored
        case .left: return .left
        case .leftMirrored: return .leftMirrored
        case .right: return .right
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
    
    static func recognize(from imageData: Data) async -> String? {
        guard let uiImage = UIImage(data: imageData) else { return nil }

        if let visionLabel = recognizeWithVision(uiImage: uiImage) {
            return visionLabel
        }

        if let heuristic = heuristicIngredient(from: uiImage) {
            print("Heuristic ingredient: \(heuristic)")
            return heuristic
        }

        return nil
    }

    private static func recognizeWithVision(uiImage: UIImage) -> String? {
        guard let cg = uiImage.cgImage else { return nil }
        let orientation = cgImageOrientation(from: uiImage.imageOrientation)
        let handler = VNImageRequestHandler(cgImage: cg, orientation: orientation, options: [:])
        let request = VNClassifyImageRequest()
        do {
            try handler.perform([request])
            guard let observations = request.results, !observations.isEmpty else { return nil }
            let sorted = observations.sorted { $0.confidence > $1.confidence }

            for obs in sorted.prefix(5) {
                if let ingredient = cleanLabel(obs.identifier) {
                    print("Using observation: \(obs.identifier) (confidence: \(obs.confidence)) -> \(ingredient)")
                    return ingredient
                }
            }

            if let best = sorted.first {
                print("Top prediction but no ingredient token found: \(best.identifier) (confidence: \(best.confidence))")
            }
            return nil
        } catch {
            print("Vision classification error: \(error)")
            return nil
        }
    }

    private static func heuristicIngredient(from uiImage: UIImage) -> String? {
        guard let color = averageColor(from: uiImage) else { return nil }
        var h: CGFloat = 0
        var s: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard color.getHue(&h, saturation: &s, brightness: &b, alpha: &a) else { return nil }

        if s < 0.25 {
            return nil
        }

        if (h <= 0.04 || h >= 0.96) && s >= 0.4 {
            return "Tomato"
        }

        if h > 0.04 && h < 0.12 && s >= 0.4 {
            return "Carrot"
        }

        if h >= 0.10 && h < 0.20 && s >= 0.2 && b > 0.5 {
            return "Potato"
        }

        // Green-heavy images → likely leafy / green vegetables
        if h >= 0.22 && h < 0.45 && s >= 0.35 {
            return "Broccoli"
        }

        // Bright, saturated yellow → corn/banana-like
        if h >= 0.18 && h < 0.26 && s >= 0.4 && b > 0.6 {
            return "Corn"
        }

        // Purple / violet tones → eggplant-like
        if h >= 0.70 && h < 0.90 && s >= 0.25 {
            return "Eggplant"
        }

        return nil
    }

    private static func averageColor(from image: UIImage) -> UIColor? {
        guard let inputImage = CIImage(image: image) else { return nil }
        let extent = inputImage.extent
        let vector = CIVector(cgRect: extent)

        guard let filter = CIFilter(name: "CIAreaAverage") else { return nil }
        filter.setValue(inputImage, forKey: kCIInputImageKey)
        filter.setValue(vector, forKey: kCIInputExtentKey)

        guard let outputImage = filter.outputImage else { return nil }

        var bitmap = [UInt8](repeating: 0, count: 4)
        let context = CIContext(options: nil)
        context.render(outputImage,
                       toBitmap: &bitmap,
                       rowBytes: 4,
                       bounds: CGRect(x: 0, y: 0, width: 1, height: 1),
                       format: .RGBA8,
                       colorSpace: CGColorSpaceCreateDeviceRGB())

        let red = CGFloat(bitmap[0]) / 255.0
        let green = CGFloat(bitmap[1]) / 255.0
        let blue = CGFloat(bitmap[2]) / 255.0
        let alpha = CGFloat(bitmap[3]) / 255.0

        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }

    private static func cleanLabel(_ label: String) -> String? {
        let lowered = label.lowercased()
        let rawTokens = lowered
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .split(separator: " ")
            .map(String.init)

        // Trim punctuation from tokens (e.g. "night," -> "night")
        let tokens = rawTokens.map { token in
            token.trimmingCharacters(in: .punctuationCharacters)
        }.filter { !$0.isEmpty }

        // Words that are too generic or non-food; we skip these entirely
        let generic: Set<String> = [
            "food","dish","cooked","raw","fresh","ingredient","meal","plate","bowl",
            "no","person","people","man","woman","indoor","outdoor","outside","inside",
            "portrait","environment","nature","landscape","background","white","black",
            "night","day","morning","evening","copyspace","closeup","studio",
            "sky","skies","cloud","clouds"
        ]

        // Common food keywords we want to strongly prefer
        let foodKeywords: [String: String] = [
            "potato": "Potato", "potatoes": "Potato",
            "tomato": "Tomato", "tomatoes": "Tomato",
            "sausage": "Sausage", "sausages": "Sausage",
            "apple": "Apple", "banana": "Banana",
            "chicken": "Chicken", "beef": "Beef", "pork": "Pork",
            "egg": "Egg", "eggs": "Eggs",
            "fish": "Fish", "salmon": "Salmon", "tuna": "Tuna",
            "rice": "Rice", "bread": "Bread", "pasta": "Pasta",
            "noodle": "Noodle", "noodles": "Noodles",
            "onion": "Onion", "garlic": "Garlic",
            "carrot": "Carrot", "broccoli": "Broccoli",
            "cheese": "Cheese", "yogurt": "Yogurt", "milk": "Milk",
            "pizza": "Pizza", "burger": "Burger", "sandwich": "Sandwich"
        ]

        // 1) Exact food keyword match
        for token in tokens {
            if let mapped = foodKeywords[token] {
                return mapped
            }
        }

        // 2) Fallback: first non-generic, reasonably long token
        if let token = tokens.first(where: { !generic.contains($0) && $0.count >= 3 }) {
            return token.prefix(1).uppercased() + token.dropFirst()
        }

        // Nothing usable found
        return nil
    }
}
