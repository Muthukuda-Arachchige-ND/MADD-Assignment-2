//
//  OnboardingView.swift
//  MealMind
//
//  Created by IM Student on 2025-11-16.
//

import SwiftUI

struct OnboardingView: View {
    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = false
    @State private var selection = 0

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.green.opacity(0.35), Color.blue.opacity(0.35)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack {
                TabView(selection: $selection) {
                    OnboardingPage(
                        systemImage: "fork.knife",
                        title: "Welcome to MealMind",
                        message: "Turn any ingredient into quick and simple meals."
                    )
                    .tag(0)

                    OnboardingPage(
                        systemImage: "camera.metering.matrix",
                        title: "Scan Ingredients",
                        message: "Pick or snap a photo and let MealMind guess the ingredient."
                    )
                    .tag(1)

                    OnboardingPage(
                        systemImage: "list.bullet.rectangle",
                        title: "Get Easy Recipes",
                        message: "Browse a few hand-picked, beginner-friendly recipes."
                    )
                    .tag(2)
                }
                .tabViewStyle(.page)
                .indexViewStyle(.page(backgroundDisplayMode: .interactive))

                Button {
                    hasSeenOnboarding = true
                } label: {
                    Text("Get Started")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.thinMaterial)
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .padding(.horizontal)
                        .padding(.bottom, 20)
                }
            }
        }
    }
}

private struct OnboardingPage: View {
    let systemImage: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 24) {
            Spacer()

            Image(systemName: systemImage)
                .font(.system(size: 80))
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.white)

            Text(title)
                .font(.largeTitle.weight(.bold))
                .multilineTextAlignment(.center)

            Text(message)
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)

            Spacer()
        }
    }
}

#Preview {
    OnboardingView()
}
