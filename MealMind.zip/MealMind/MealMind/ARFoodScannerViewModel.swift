import Foundation
import Combine

class ARFoodScannerViewModel: ObservableObject {
    @Published var isScanning = false
    @Published var detectedFood: String? = nil
    
    func startScanning() {
        isScanning = true
        detectedFood = nil
        
        // Simulate food detection after a short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            guard let self = self, self.isScanning else { return }
            self.detectedFood = "Apple" // Placeholder detected ingredient
        }
    }
    
    func stopScanning() {
        isScanning = false
        detectedFood = nil
    }
}
